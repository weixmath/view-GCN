import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
from tensorboardX import SummaryWriter
# from torch.cuda.amp import autocast as autocast
# from torch.cuda.amp import GradScaler as GradScaler
import math
from torch.optim.lr_scheduler import CosineAnnealingLR
class ModelNetTrainer(object):
    def __init__(self, model, train_loader, val_loader, optimizer, loss_fn, \
                 model_name, log_dir, num_views=12):
        self.optimizer = optimizer
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.loss_fn = loss_fn
        self.model_name = model_name
        self.log_dir = log_dir
        self.num_views = num_views
        self.model.cuda()
        if self.log_dir is not None:
            self.writer = SummaryWriter(log_dir)
    def train(self, n_epochs):
        best_acc = 0
        best_per_cls_acc = 0
        i_acc = 0
        self.model.train()
        # scaler = GradScaler()
        scheduler = CosineAnnealingLR(self.optimizer,T_max=60,eta_min=0)
        for epoch in range(n_epochs):
            rand_idx = np.random.permutation(int(len(self.train_loader.dataset.filepaths) / self.num_views))
            filepaths_new = []
            for i in range(len(rand_idx)):
                filepaths_new.extend(self.train_loader.dataset.filepaths[
                                     rand_idx[i] * self.num_views:(rand_idx[i] + 1) * self.num_views])
            self.train_loader.dataset.filepaths = filepaths_new
            # plot learning rate
            lr = self.optimizer.state_dict()['param_groups'][0]['lr']
            self.writer.add_scalar('params/lr', lr, epoch)
            # train one epoch
            out_data = None
            in_data = None
            # if self.num_views == 20:
            phi = (1 + np.sqrt(5)) / 2
            # vertices = [[-0.0686, -0.8123, -1.5282],[0.7878, 1.1065, 1.0747],
            #             [1.7234, -0.1717, -0.0223],[-0.5227, -1.5625, 0.5342],[-1.0436, -0.7438, 1.1652],
            #             [0.6031, 0.7876, -1.4198],[0.7741, 1.3948, 0.6748],[-1.7301, 0.0664, -0.0466],
            #             [-0.2507, 1.6569, -0.4378],[-0.3726, -1.5687, 0.6328],[1.6836, 0.3574, -0.1946],
            #             [-1.6738, 0.1534, 0.4180]]
                # ,[-1.4893, -0.5519, -0.6910],[0.6513, 0.0159, -1.6048],
                #         [-0.1179, -0.9122, -1.4677],[0.4960, -1.5642, -0.5543],[0.8340, -0.4053, 1.4629],
                #         [-0.6122, 0.9454, -1.3159],[-0.0797, 1.7289, 0.0677],[-0.6867, -0.8558, 1.3402]]
            vertices = [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1],
                        [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1],
                        [0, 1 / phi, phi], [0, 1 / phi, -phi], [0, -1 / phi, phi], [0, -1 / phi, -phi],
                        [phi, 0, 1 / phi], [phi, 0, -1 / phi], [-phi, 0, 1 / phi], [-phi, 0, -1 / phi],
                        [1 / phi, phi, 0], [-1 / phi, phi, 0], [1 / phi, -phi, 0], [-1 / phi, -phi, 0]]
            vertices = torch.tensor(vertices).float().cuda()
            # elif self.num_views == 12:
            #     phi = np.sqrt(3)
            #     vertices = [[1, 0, phi / 3], [phi / 2, -1 / 2, phi / 3], [1 / 2, -phi / 2, phi / 3],
            #                 [0, -1, phi / 3], [-1 / 2, -phi / 2, phi / 3], [-phi / 2, -1 / 2, phi / 3],
            #                 [-1, 0, phi / 3], [-phi / 2, 1 / 2, phi / 3], [-1 / 2, phi / 2, phi / 3],
            #                 [0, 1, phi / 3], [1 / 2, phi / 2, phi / 3], [phi / 2, 1 / 2, phi / 3]]
            #     vertices = torch.tensor(vertices).float().cuda()
            for i, data in enumerate(self.train_loader):
                if epoch == 0:
                    for param_group in self.optimizer.param_groups:
                        param_group['lr'] = lr * ((i + 1) / (len(rand_idx) // 20))
                if self.model_name == 'view-gcn':
                    N, V, C, H, W = data[1].size()
                    in_data = Variable(data[1]).view(-1, C, H, W).cuda()
                    # in_data = Variable(data[1][:,:12,:,:,:]).reshape(-1, C, H, W).cuda()
                else:
                    in_data = Variable(data[1].cuda())
                target = Variable(data[0]).cuda().long()
                target_ = target.unsqueeze(1).repeat(1, 2*(10+5)).view(-1)
                self.optimizer.zero_grad()
                # with autocast():
                if self.model_name == 'view-gcn':
                    out_data,F_score,F_score2 = self.model(in_data,vertices)
                    out_data_ = torch.cat((F_score, F_score2), 1).view(-1, 40)
                    loss1= self.loss_fn(out_data, target)
                    loss2 = self.loss_fn(out_data_, target_)
                    loss = loss1+loss2
                        # loss3 = self.loss_fn(y.view(-1,40),target.unsqueeze(1).repeat(1,20).view(-1))
                        # loss = loss1+loss2+loss3
                else:
                    out_data = self.model(in_data)
                    loss = self.loss_fn(out_data, target)
                self.writer.add_scalar('train/train_loss', loss, i_acc + i + 1)
                pred = torch.max(out_data, 1)[1]
                results = pred == target
                correct_points = torch.sum(results.long())

                acc = correct_points.float() / results.size()[0]
                self.writer.add_scalar('train/train_overall_acc', acc, i_acc + i + 1)
                # print('lr = ', str(param_group['lr']))
                # scaler.scale(loss).backward()
                # scaler.step(self.optimizer)
                # scaler.update()
                loss.backward()
                self.optimizer.step()
                self.optimizer.zero_grad()
                # loss.backward()
                # self.optimizer.step()
                log_str = 'epoch %d, step %d: train_loss %.3f; train_acc %.3f' % (epoch + 1, i + 1, loss, acc)
                if (i + 1) % 1 == 0:
                    print(log_str)
            if epoch>0:
                scheduler.step()
            i_acc += i
            # evaluation
            if (epoch + 1) % 1 == 0:
                print(scheduler.get_last_lr())
                with torch.no_grad():
                    loss, val_overall_acc, val_mean_class_acc = self.update_validation_accuracy(epoch)
                self.writer.add_scalar('val/val_mean_class_acc', val_mean_class_acc, epoch + 1)
                self.writer.add_scalar('val/val_overall_acc', val_overall_acc, epoch + 1)
                self.writer.add_scalar('val/val_loss', loss, epoch + 1)

            # save best model
                if val_overall_acc > best_acc:
                    best_acc = val_overall_acc
                    best_per_cls_acc = val_mean_class_acc
                    self.model.save(self.log_dir, epoch)
        print('best_acc', best_acc)
        print('best_per_cls_acc',best_per_cls_acc)
        # export scalar data to JSON for external processing
        self.writer.export_scalars_to_json(self.log_dir + "/all_scalars.json")
        self.writer.close()
    # def update_validation_accuracy(self, epoch):
    #     v_cand = np.load('./vcand_case2.npy')
    #     v_cand = torch.Tensor(v_cand)
    #     all_correct_points = 0
    #     all_points = 0
    #     count = 0
    #     wrong_class = np.zeros(15)
    #     samples_class = np.zeros(15)
    #     all_loss = 0
    #     self.model.eval()
    #     feat1 = []
    #     feat2 = []
    #     pred_label = []
    #     file_name = self.val_loader.dataset.filepaths
    #     # file = open('feat_aligned/list_aligned.txt', 'w')
    #     # for fp in file_name:
    #     #     file.write(str(fp))
    #     #     file.write('\n')
    #     # file.close()
    #     # count = 0
    #     # print('保存文档成功！')
    #
    #     # if self.num_views == 20:
    #     phi = (1 + np.sqrt(5)) / 2
    #     vertices = [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1],
    #                 [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1],
    #                 [0, 1 / phi, phi], [0, 1 / phi, -phi], [0, -1 / phi, phi], [0, -1 / phi, -phi],
    #                 [phi, 0, 1 / phi], [phi, 0, -1 / phi], [-phi, 0, 1 / phi], [-phi, 0, -1 / phi],
    #                 [1 / phi, phi, 0], [-1 / phi, phi, 0], [1 / phi, -phi, 0], [-1 / phi, -phi, 0]]
    #     vertices = torch.tensor(vertices).float().cuda()
    #     # elif self.num_views == 12:
    #     #     phi = np.sqrt(3)
    #     #     vertices = [[1, 0, phi / 3], [phi / 2, -1 / 2, phi / 3], [1 / 2, -phi / 2, phi / 3],
    #     #                 [0, -1, phi / 3], [-1 / 2, -phi / 2, phi / 3], [-phi / 2, -1 / 2, phi / 3],
    #     #                 [-1, 0, phi / 3], [-phi / 2, 1 / 2, phi / 3], [-1 / 2, phi / 2, phi / 3],
    #     #                 [0, 1, phi / 3], [1 / 2, phi / 2, phi / 3], [phi / 2, 1 / 2, phi / 3]]
    #     #     vertices = torch.tensor(vertices).float().cuda()
    #     for _, data in enumerate(self.val_loader, 0):
    #
    #         if self.model_name == 'view-gcn':
    #             N, V, C, H, W = data[1].size()
    #             in_data = Variable(data[1]).view(-1, C, H, W).cuda()
    #         else:  # 'svcnn'
    #             in_data = Variable(data[1]).cuda()
    #         target = Variable(data[0]).cuda()
    #
    #         # iii = torch.randint(0,60,[target.shape[0]])
    #         # v_cand_2 = torch.index_select(v_cand,0,iii).long()
    #         # in_data = in_data.view(-1,20,3,224,224)
    #         # mm = torch.arange(0,target.shape[0]).unsqueeze(1).repeat(1,20)
    #         # in_data = in_data[mm,v_cand_2,:,:,:]
    #         # in_data = in_data.view(-1,3,224,224).contiguous()
    #         #
    #         if self.model_name == 'view-gcn':
    #             out_data=self.model(in_data,vertices)
    #         else:
    #             out_data = self.model(in_data,vertices)
    #         pred = torch.max(out_data, 1)[1]
    #         # feat1.append(out_data.detach().cpu().numpy())
    #         # feat2.append(f2.detach().cpu().numpy())
    #         # pred_label.append(pred.detach().cpu().numpy())
    #         count = count + 1
    #         print('count is:', count)
    #     # np.save('feat_aligned/feat1_aligned.npy', np.concatenate(feat1, axis=0))
    #     # np.save('test2/feat2_perturbed.npy', np.concatenate(feat2, axis=0))
    #     # np.save('feat_aligned/label_aligned.npy', np.concatenate(pred_label, axis=0))
    #     # print('finished!!!!!!!!')
    def update_validation_accuracy(self, epoch):
        all_correct_points = 0
        all_points = 0
        count = 0
        wrong_class = np.zeros(40)
        samples_class = np.zeros(40)
        all_loss = 0
        self.model.eval()
        phi = (1 + np.sqrt(5)) / 2
        # vertices = [[-0.0686, -0.8123, -1.5282], [0.7878, 1.1065, 1.0747],
        #             [1.7234, -0.1717, -0.0223], [-0.5227, -1.5625, 0.5342], [-1.0436, -0.7438, 1.1652],
        #             [0.6031, 0.7876, -1.4198], [0.7741, 1.3948, 0.6748], [-1.7301, 0.0664, -0.0466],
        #             [-0.2507, 1.6569, -0.4378], [-0.3726, -1.5687, 0.6328], [1.6836, 0.3574, -0.1946],
        #             [-1.6738, 0.1534, 0.4180]]
        vertices = [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1],
                    [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1],
                    [0, 1 / phi, phi], [0, 1 / phi, -phi], [0, -1 / phi, phi], [0, -1 / phi, -phi],
                    [phi, 0, 1 / phi], [phi, 0, -1 / phi], [-phi, 0, 1 / phi], [-phi, 0, -1 / phi],
                    [1 / phi, phi, 0], [-1 / phi, phi, 0], [1 / phi, -phi, 0], [-1 / phi, -phi, 0]]
        vertices = torch.tensor(vertices).float().cuda()
        for _, data in enumerate(self.val_loader, 0):

            if self.model_name == 'view-gcn':
                N, V, C, H, W = data[1].size()
                in_data = Variable(data[1]).view(-1, C, H, W).cuda()
                # in_data = Variable(data[1][:, :12, :, :, :]).reshape(-1, C, H, W).cuda()
            else:  # 'svcnn'
                in_data = Variable(data[1]).cuda()
            target = Variable(data[0]).cuda()
            if self.model_name == 'view-gcn':
                out_data,F1,F2=self.model(in_data,vertices)
            else:
                out_data = self.model(in_data)
            pred = torch.max(out_data, 1)[1]
            all_loss += self.loss_fn(out_data, target).cpu().data.numpy()
            results = pred == target

            for i in range(results.size()[0]):
                if not bool(results[i].cpu().data.numpy()):
                    wrong_class[target.cpu().data.numpy().astype('int')[i]] += 1
                samples_class[target.cpu().data.numpy().astype('int')[i]] += 1
            correct_points = torch.sum(results.long())

            all_correct_points += correct_points
            all_points += results.size()[0]

        print('Total # of test models: ', all_points)
        class_acc = (samples_class - wrong_class) / samples_class
        val_mean_class_acc = np.mean(class_acc)
        acc = all_correct_points.float() / all_points
        val_overall_acc = acc.cpu().data.numpy()
        loss = all_loss / len(self.val_loader)

        print('val mean class acc. : ', val_mean_class_acc)
        print('val overall acc. : ', val_overall_acc)
        print('val loss : ', loss)
        print(class_acc)
        self.model.train()

        return loss, val_overall_acc, val_mean_class_acc