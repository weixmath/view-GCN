import torch
import torch.nn as nn
import math
import numpy as np
import torch.nn.functional as Functional
from models.transformer.encoders import EncoderLayer
def square_distance(src, dst):
    B, N, _ = src.shape
    _, M, _ = dst.shape
    dist = -2 * torch.matmul(src, dst.permute(0, 2, 1))
    dist += torch.sum(src ** 2, -1).view(B, N, 1)
    dist += torch.sum(dst ** 2, -1).view(B, 1, M)
    return dist

def index_points(points, idx):
    """
    Input:
        points: input points data, [B, N, C]
        idx: sample index data, [B, S]
    Return:
        new_points:, indexed points data, [B, S, C]
    """
    device = points.device
    B = points.shape[0]
    view_shape = list(idx.shape)
    view_shape[1:] = [1] * (len(view_shape) - 1)
    repeat_shape = list(idx.shape)
    repeat_shape[0] = 1
    batch_indices = torch.arange(B, dtype=torch.long).to(device).view(view_shape).repeat(repeat_shape)
    new_points = points[batch_indices, idx, :]
    return new_points

def farthest_point_sample(xyz, npoint):
    """
    Input:
        xyz: pointcloud data, [B, N, 3]
        npoint: number of samples
    Return:
        centroids: sampled pointcloud index, [B, npoint]
    """
    device = xyz.device
    B, N, C = xyz.shape
    centroids = torch.zeros(B, npoint, dtype=torch.long).to(device)
    distance = torch.ones(B, N).to(device) * 1e10
    farthest = torch.randint(0, N, (B,), dtype=torch.long).to(device)
    # farthest = torch.zeros(B,dtype=torch.long).to(device)
    batch_indices = torch.arange(B, dtype=torch.long).to(device)
    for i in range(npoint):
        centroids[:, i] = farthest
        centroid = xyz[batch_indices, farthest, :].view(B, 1, 3)
        dist = torch.sum((xyz - centroid) ** 2, -1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = torch.max(distance, -1)[1]
    return centroids

def knn(nsample, xyz, new_xyz):
    dist = square_distance(xyz, new_xyz)
    id = torch.topk(dist,k=nsample,dim=1,largest=False)[1]
    id = torch.transpose(id, 1, 2)
    return id

class KNN_dist(nn.Module):
    def __init__(self,k):
        super(KNN_dist, self).__init__()
        self.R = nn.Sequential(
            nn.Linear(10,10),
            nn.LeakyReLU(0.2,inplace=True),
            nn.Linear(10,10),
            nn.LeakyReLU(0.2,inplace=True),
            nn.Linear(10,1),
        )
        self.k=k
    def forward(self,F,vertices):
        id = knn(self.k, vertices, vertices)
        F = index_points(F,id)
        v = index_points(vertices,id)
        v_0 = v[:,:,0,:].unsqueeze(-2).repeat(1,1,self.k,1)
        v_F = torch.cat((v_0, v, v_0-v,torch.norm(v_0-v,dim=-1,p=2).unsqueeze(-1)),-1)
        v_F = self.R(v_F)
        F = torch.mul(v_F, F)
        F = torch.sum(F,-2)
        return F

class View_selector(nn.Module):
    def __init__(self, n_views, sampled_view):
        super(View_selector, self).__init__()
        self.n_views = n_views
        self.s_views = sampled_view
        self.cls = nn.Sequential(
            nn.Linear(512*self.s_views, 256*self.s_views),
            nn.LeakyReLU(0.2),
            nn.Linear(256*self.s_views,40*self.s_views))
    def forward(self,F,vertices,k):
        id = farthest_point_sample(vertices,self.s_views)
        vertices1 = index_points(vertices,id)
        id_knn = knn(k,vertices,vertices1)
        F = index_points(F,id_knn)
        vertices = index_points(vertices,id_knn)
        F1 = F.transpose(1,2).reshape(F.shape[0],k,self.s_views*F.shape[-1])
        F_score = self.cls(F1).reshape(F.shape[0],k,self.s_views,40).transpose(1,2)
        F1_ = Functional.softmax(F_score,-3)
        F1_ = torch.max(F1_,-1)[0]
        F1_id = torch.argmax(F1_,-1)
        F1_id = Functional.one_hot(F1_id,k).float()
        F1_id_v = F1_id.unsqueeze(-1).repeat(1,1,1,3)
        F1_id_F = F1_id.unsqueeze(-1).repeat(1, 1, 1, 512)
        F_new = torch.mul(F1_id_F,F).sum(-2)
        vertices_new = torch.mul(F1_id_v,vertices).sum(-2)
        return F_new,F_score,vertices_new
class FPS(nn.Module):
    def __init__(self, n_views, sampled_view):
        super(FPS, self).__init__()
        self.n_views = n_views
        self.s_views = sampled_view
    def forward(self,F,vertices,k):
        id = farthest_point_sample(vertices,self.s_views)
        vertices_new = index_points(vertices,id)
        # id_knn = knn(k,vertices,vertices1)
        F_new = index_points(F,id)
        # vertices = index_points(vertices,id_knn)
        # F1 = F.transpose(1,2).reshape(F.shape[0],k,self.s_views*F.shape[-1])
        # F_score = self.cls(F1).reshape(F.shape[0],k,self.s_views,15).transpose(1,2)
        # F1_ = Functional.softmax(F_score,-3)
        # F1_ = torch.max(F1_,-1)[0]
        # F1_id = torch.argmax(F1_,-1)
        # F1_id = Functional.one_hot(F1_id,4).float()
        # F1_id_v = F1_id.unsqueeze(-1).repeat(1,1,1,3)
        # F1_id_F = F1_id.unsqueeze(-1).repeat(1, 1, 1, 512)
        # F_new = torch.mul(F1_id_F,F).sum(-2)
        # vertices_new = torch.mul(F1_id_v,vertices).sum(-2)
        return F_new,vertices_new
class LocalGCN(nn.Module):
    def __init__(self,k,n_views):
        super(LocalGCN,self).__init__()
        self.conv = nn.Sequential(
            nn.Linear(512, 512),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.k = k
        self.n_views = n_views
        self.KNN = KNN_dist(k=self.k)
    def forward(self,F,V):
        F = self.KNN(F, V)
        F = F.view(-1, 512)
        F = self.conv(F)
        F = F.view(-1, self.n_views, 512)
        return F
class View_selector_RI_noshare(nn.Module):
    def __init__(self, n_views, sampled_view):
        super(View_selector_RI_noshare, self).__init__()
        self.n_views = n_views
        self.s_views = sampled_view
        self.cls = nn.Sequential(
            nn.Linear(512*self.s_views, 256*self.s_views),
            nn.LeakyReLU(0.2),
            nn.Linear(256*self.s_views,40*self.s_views))
    def forward(self,F0,vertices0,k):
        F_initial = F0.repeat(1,1,self.s_views)
        score0 = self.cls(F_initial)
        score0 = score0[:,:,:15]
        score= Functional.softmax(score0,-1)
        score = torch.max(score,-1)[0]
        id0 = torch.argmax(score,-1)
        vertices = vertices0.clone()
        F = F0.clone()
        vertices[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:],vertices[torch.arange(0,F.shape[0]),id0,:] = vertices0[torch.arange(0,F.shape[0]),id0,:],vertices0[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:]
        F[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:],F[torch.arange(0,F.shape[0]),id0,:] = F0[torch.arange(0,F.shape[0]),id0,:],F0[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:]
        vertices.contiguous()
        F.contiguous()
        id = farthest_point_sample(vertices,self.s_views)
        vertices1 = index_points(vertices,id)
        id_knn = knn(k,vertices,vertices1)
        F = index_points(F,id_knn)
        vertices = index_points(vertices,id_knn)
        F1 = F.transpose(1,2).reshape(F.shape[0],k,self.s_views*F.shape[-1])
        F_score = self.cls(F1).reshape(F.shape[0],k,self.s_views,40).transpose(1,2)
        F1_ = Functional.softmax(F_score,-3)
        F1_ = torch.max(F1_,-1)[0]
        F1_id = torch.argmax(F1_,-1)
        F1_id = Functional.one_hot(F1_id,4).float()
        F1_id_v = F1_id.unsqueeze(-1).repeat(1,1,1,3)
        F1_id_F = F1_id.unsqueeze(-1).repeat(1, 1, 1, 512)
        F_new = torch.mul(F1_id_F,F).sum(-2)
        vertices_new = torch.mul(F1_id_v,vertices).sum(-2)
        return F_new,F_score,vertices_new

class View_selector_RI(nn.Module):
    def __init__(self, n_views, sampled_view):
        super(View_selector_RI, self).__init__()
        self.n_views = n_views
        self.s_views = sampled_view
        self.cls = nn.Sequential(
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256,40))
    def forward(self,F0,vertices0,k):
        # F_view = F0.clone().detach()
        # score0 = self.cls(F_view)
        score0 = self.cls(F0)
        score= Functional.softmax(score0,-1)
        score = torch.max(score,-1)[0]
        id0 = torch.argmax(score,-1)
        vertices = vertices0.clone()
        F = F0.clone()
        vertices[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:],vertices[torch.arange(0,F.shape[0]),id0,:] = vertices0[torch.arange(0,F.shape[0]),id0,:],vertices0[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:]
        F[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:],F[torch.arange(0,F.shape[0]),id0,:] = F0[torch.arange(0,F.shape[0]),id0,:],F0[torch.arange(0,F.shape[0]),torch.zeros_like(id0),:]
        vertices.contiguous()
        F.contiguous()
        id = farthest_point_sample(vertices,self.s_views)
        vertices1 = index_points(vertices,id)
        id_knn = knn(k,vertices,vertices1)
        F = index_points(F,id_knn)
        vertices = index_points(vertices,id_knn)
        F1 = F.transpose(1,2).reshape(F.shape[0],k,self.s_views,F.shape[-1])
        F_score = self.cls(F1).reshape(F.shape[0],k,self.s_views,40).transpose(1,2)
        F1_ = Functional.softmax(F_score,-3)
        F1_ = torch.max(F1_,-1)[0]
        F1_id = torch.argmax(F1_,-1)
        F1_id = Functional.one_hot(F1_id,k).float()
        F1_id_v = F1_id.unsqueeze(-1).repeat(1,1,1,3)
        F1_id_F = F1_id.unsqueeze(-1).repeat(1, 1, 1, 512)
        F_new = torch.mul(F1_id_F,F).sum(-2)
        vertices_new = torch.mul(F1_id_v,vertices).sum(-2)
        return F_new,score0,vertices_new

class NonLocalMP(nn.Module):
    def __init__(self,n_view):
        super(NonLocalMP,self).__init__()
        self.n_view=n_view
        self.Relation = nn.Sequential(
            nn.Linear(2 * 512, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 512),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.Fusion = nn.Sequential(
            nn.Linear(2 * 512, 512),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
        )
    def forward(self, F):
        F_i = torch.unsqueeze(F, 2)
        F_j = torch.unsqueeze(F, 1)
        F_i = F_i.repeat(1, 1, self.n_view, 1)
        F_j = F_j.repeat(1, self.n_view, 1, 1)
        M = torch.cat((F_i, F_j), 3)
        M = self.Relation(M)
        M = torch.sum(M,-2)
        # M = M.mean(2)
        F = torch.cat((F, M), 2)
        F = F.view(-1, 512 * 2)
        F = self.Fusion(F)
        F = F.view(-1, self.n_view, 512)
        return F
class LocalGAT(nn.Module):

    def __init__(self, k, n_views,d_model=512,d_k=512,d_v=512,h=4):
        '''
        :param d_model: Output dimensionality of the model
        :param d_k: Dimensionality of queries and keys
        :param d_v: Dimensionality of values
        :param h: Number of heads
        '''
        super(LocalGAT, self).__init__()
        self.k = k
        self.n_views = n_views
        self.fc_q = nn.Linear(d_model, h * d_k)
        self.fc_k = nn.Linear(d_model, h * d_k)
        self.fc_v = nn.Linear(d_model, h * d_v)
        self.fc_o = nn.Linear(h * d_v, d_model)
        self.fc_v_q = nn.Linear(3,3)
        self.fc_v_k = nn.Linear(3,3)
        self.lr = nn.LeakyReLU(0.2)
        self.fc = nn.Sequential(
            nn.Linear(2,2),
            nn.LeakyReLU(0.2),
            nn.Linear(2,2),
            nn.LeakyReLU(0.2),
            nn.Linear(2,1)
        )
        self.fc2 = nn.Linear(2,1,bias=False)
        self.d_model = d_model
        self.d_k = d_k
        self.d_v = d_v
        self.h = h
        self.bn = nn.BatchNorm1d(d_model)
        self.init_weights()

    def init_weights(self):
        nn.init.xavier_uniform_(self.fc_q.weight)
        nn.init.xavier_uniform_(self.fc_k.weight)
        nn.init.xavier_uniform_(self.fc_v_q.weight)
        nn.init.xavier_uniform_(self.fc_v_k.weight)
        nn.init.xavier_uniform_(self.fc_v.weight)
        nn.init.xavier_uniform_(self.fc_o.weight)
        nn.init.constant_(self.fc_q.bias, 0)
        nn.init.constant_(self.fc_k.bias, 0)
        nn.init.constant_(self.fc_v.bias, 0)
        nn.init.constant_(self.fc_o.bias, 0)
        nn.init.constant_(self.fc_v_q.bias, 0)
        nn.init.constant_(self.fc_v_k.bias, 0)

    def forward(self,F,vertices):
        b_s, nq = F.shape[:2]
        nk = F.shape[1]
        id = knn(self.k, vertices, vertices)
        id2 = torch.nn.functional.one_hot(id, self.n_views).sum(-2).unsqueeze(1).repeat(1, self.h, 1, 1)
        attention_mask = id2 < 1
        attention_weights = None
        q = self.fc_q(F).view(b_s, nq, self.h, self.d_k).permute(0, 2, 1, 3)  # (b_s, h, nq, d_k)
        k = self.fc_k(F).view(b_s, nk, self.h, self.d_k).permute(0, 2, 3, 1)  # (b_s, h, d_k, nk)
        # q = F.view(b_s, nq, self.h, self.d_k).permute(0, 2, 1, 3)
        # k = F.view(b_s, nk, self.h, self.d_k).permute(0, 2, 3, 1)
        v = F.view(b_s,nk,1,self.d_k).repeat(1,1,self.h,1).permute(0, 2, 1, 3)
        # v = v.repeat(1,self.h,1,1)
        # v = self.fc_v(F).view(b_s, nk, self.h, self.d_v).permute(0, 2, 1, 3)  # (b_s, h, nk, d_v)
        # vertices_q = self.fc_v_q(vertices)
        # vertices_k = self.fc_v_k(vertices)
        att_pos1 = torch.matmul(vertices,vertices.transpose(1,2)).unsqueeze(1)
        att_pos2 = torch.sqrt(torch.sum((vertices.unsqueeze(1).repeat(1,nk,1,1)-vertices.unsqueeze(2).repeat(1,1,nk,1))**2,-1)).unsqueeze(1)
        att_pos = torch.cat((att_pos1,att_pos2),1)
        att = torch.matmul(q, k) / np.sqrt(self.d_k)  # (b_s, h, nq, nk)
        # att = torch.cat((att,att_pos),1)
        # att = att.permute(0,2,3,1)
        # att = self.fc(att)
        # att = att.permute(0,3,1,2)
        att_pos = att_pos.permute(0,2,3,1)
        att_pos = self.fc(att_pos)
        att_pos = att_pos.permute(0,3,1,2)
        att_pos = att_pos.repeat(1,self.h,1,1)
        # print(att_pos.shape)
        if attention_weights is not None:
            att = att * attention_weights
        if attention_mask is not None:
            att = att.masked_fill(attention_mask, -np.inf)
            att_pos = att_pos.masked_fill(attention_mask, -np.inf)
        att = torch.softmax(att, -1)
        att_pos = torch.softmax(att_pos, -1)
        # att = torch.cat((att,att_pos),1)
        # att = att.permute(0,2,3,1)
        # att = self.fc2(att)
        # att = att.permute(0,3,1,2)
        # att_pos = att_pos.repeat(1,self.h,1,1)
        # print(att.shape)
        # print(att_pos.shape)
        att = (att+att_pos)/2
        # att = torch.softmax(att,-1)
        # out = torch.matmul(att,v)+v
        # out = out.permute(0, 2, 1, 3).contiguous().view(b_s, nq, self.h * self.d_v)
        out = torch.matmul(att, v).permute(0, 2, 1, 3).contiguous().view(b_s, nq, self.h * self.d_v)  # (b_s, nq, h*d_v)
        out = self.fc_o(out)  # (b_s, nq, d_model)
        out = self.lr(self.bn(out.transpose(1, 2))).transpose(1, 2)
        return out
